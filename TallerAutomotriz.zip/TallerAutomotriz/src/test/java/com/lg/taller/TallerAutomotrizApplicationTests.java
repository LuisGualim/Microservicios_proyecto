package com.lg.taller;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TallerAutomotrizApplicationTests {

	@Test
	void contextLoads() {
	}

}
