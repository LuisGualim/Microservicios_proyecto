package com.lg.taller.repository;

import com.lg.taller.entity.HistorialServicio;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HistorialServicioRepository extends JpaRepository<HistorialServicio, Long> {
	
}
